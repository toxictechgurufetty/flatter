package com.example.ipa_testing_github_action

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
